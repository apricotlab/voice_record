// See https://github.com/dialogflow/dialogflow-fulfillment-nodejs
// for Dialogflow fulfillment library docs, samples, and to report issues
'use strict';
 
const functions = require('firebase-functions');
const {WebhookClient} = require('dialogflow-fulfillment');
const {Card, Suggestion} = require('dialogflow-fulfillment');
 
process.env.DEBUG = 'dialogflow:debug'; // enables lib debugging statements
 
exports.dialogflowFirebaseFulfillment = functions.https.onRequest((request, response) => {
  const agent = new WebhookClient({ request, response });
  console.log('Dialogflow Request headers: ' + JSON.stringify(request.headers));
  console.log('Dialogflow Request body: ' + JSON.stringify(request.body));
 
  function welcome(agent) {
    agent.add(`Welcome to my agent!`);
  }
 
  function fallback(agent) {
    agent.add(`I didn't understand`);
    agent.add(`I'm sorry, can you try again?`);
  }

   function menuintro(agent) {
          let servicemenuchoice = agent.parameters.SERVICEMENU;
     
     　 console.log('params:' + servicemenuchoice);
     
        if (servicemenuchoice == '研修'){
//        agent.setContext({SERVICEMENU: '研修'});  
//        conv.contexts.set('SERVICEMENU',3,'研修');  
        agent.add('弊社の研修は、基本的には１日コースです。');
        agent.add('この音声システムのようなチャットを実際に作成します。');
//         agent.add('研修は週末にやっております。参加費は３万円です。"');  
        } else if (servicemenuchoice == '開発'){
        agent.add("開発委託は、貴社のために弊社がチャットのシステムを開発するサービスです");
        agent.add("弊社は多くの開発経験があるため、多少難易度が高いものも短期間で開発できます");
                 } else if (servicemenuchoice == 'コンサル'){
        agent.add("コンサルでは、貴社の業務内容をヒアリングし、AIが活用できる箇所を見つけ出します。");
        agent.add("AIの活用の成功には必須だと思います。");
                  } else if (servicemenuchoice == '全部'){
        agent.add("了解いたしました。通常、弊社のサービスは、コンサル、研修を実施します。");
        agent.add("その結果、開発委託の必要性を検討していただきます。");
        } else {
//        agent.add(`You have successfully booked a table for ${guests} guests on ${bookingDate.toString().slice(0,21)}`);
         agent.add("それは残念です。引き続きサービスメニューの改善に努めます。");
    }
}
      
  function howmuch(agent) {
          let servicemenuchoice = agent.parameters.SERVICEMENU;
     
     　 console.log('params:' + servicemenuchoice);
     
        if (servicemenuchoice == '研修'){  
        agent.add('弊社主催の研修の場合、１日、１名、３万円となります。');
        agent.add('また、御社へ御訪問し、研修を実施する場合、15万円となります。 生徒の上限として５名とさせていただいております。');
        } else if (servicemenuchoice == '開発'){
        agent.add("開発委託の料金は、弊社でサポートさせていただく部分によります。");
        agent.add("当チャット程度の開発の場合、２日目安で、過去の例ですと、15万円程度頂戴しています。");
                 } else if (servicemenuchoice == 'コンサル'){
        agent.add("コンサルは、一日、8万円頂戴しております。");
                  } else if (servicemenuchoice == '全部'){
        agent.add("了解いたしました。通常、当チャット開発をゴールとして、コンサル、研修、実装まで実施して、30万から50万程度となっております。");
        } else {
//        agent.add(`You have successfully booked a table for ${guests} guests on ${bookingDate.toString().slice(0,21)}`);
         agent.add("何だかわからん");
    }
}
           
      
      

  
  // // Uncomment and edit to make your own intent handler
  // // uncomment `intentMap.set('your intent name here', yourFunctionHandler);`
  // // below to get this function to be run when a Dialogflow intent is matched
  // function yourFunctionHandler(agent) {
  //   agent.add(`This message is from Dialogflow's Cloud Functions for Firebase editor!`);
  //   agent.add(new Card({
  //       title: `Title: this is a card title`,
  //       imageUrl: 'https://developers.google.com/actions/images/badges/XPM_BADGING_GoogleAssistant_VER.png',
  //       text: `This is the body text of a card.  You can even use line\n  breaks and emoji! 💁`,
  //       buttonText: 'This is a button',
  //       buttonUrl: 'https://assistant.google.com/'
  //     })
  //   );
  //   agent.add(new Suggestion(`Quick Reply`));
  //   agent.add(new Suggestion(`Suggestion`));
  //   agent.setContext({ name: 'weather', lifespan: 2, parameters: { city: 'Rome' }});
  // }

  // // Uncomment and edit to make your own Google Assistant intent handler
  // // uncomment `intentMap.set('your intent name here', googleAssistantHandler);`
  // // below to get this function to be run when a Dialogflow intent is matched
  // function googleAssistantHandler(agent) {
  //   let conv = agent.conv(); // Get Actions on Google library conv instance
  //   conv.ask('Hello from the Actions on Google client library!') // Use Actions on Google library
  //   agent.add(conv); // Add Actions on Google library responses to your agent's response
  // }
  // // See https://github.com/dialogflow/dialogflow-fulfillment-nodejs/tree/master/samples/actions-on-google
  // // for a complete Dialogflow fulfillment library Actions on Google client library v2 integration sample

  // Run the proper function handler based on the matched Dialogflow intent name
  let intentMap = new Map();
  intentMap.set('Default Welcome Intent', welcome);
  intentMap.set('Default Fallback Intent', fallback);
  intentMap.set('IAMINTERESTEDIN', menuintro);
  intentMap.set("WHATSERVICE - yes - interest",menuintro);
  intentMap.set("HOWMUCH",howmuch);
  // intentMap.set('your intent name here', yourFunctionHandler);
  // intentMap.set('your intent name here', googleAssistantHandler);
  agent.handleRequest(intentMap);
});
